# consul-ai-agent-sdk
This is SDK to build the AI agent which is capable of auto-configuration of other AI Agent and MCP Servers. The SDK is based on Google's A2A
